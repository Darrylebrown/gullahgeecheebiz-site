Gullah Geechee Encyclopedia Bundle (Heritage Collection - Language & Dialect)
Author: Darryl Elliott Brown
Publisher: Gullah Geechee Biz
Contents: 4 complete encyclopedia volumes (real EPUB files).
